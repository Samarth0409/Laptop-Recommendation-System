class demo {
   public static void main(String[] args){
      int a = Integer.valueOf(args[0]);
      System.out.println("The integer was = "+a);
   }
}