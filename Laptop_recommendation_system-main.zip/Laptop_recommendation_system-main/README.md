## Laptop_recommendation_system

#Introduction

Laptop has become one of the most essential and used items in our daily life. With the overwhelming amount of specifications and brand names on the market, it becomes difficult for laptop makers to sell their products and for customers to pick their laptop. The Laptop Recommendation System (LRS) is a web-based application is intended to provide customers and the viewers with all the information about the laptops available online which can be selected by the user and can be viewed without going to the actual showroom physically. 

#Scope

The benefit of using this web-based application is that you can search, compare or get recommended by the app that which laptop is better for you to buy without going to the shop and getting confused between different brands. And the system and algorithm are designed in such a way that, for recommendation of the laptops, users aren’t expected to be fully knowledgeable about the laptops and the technologies used in it.

